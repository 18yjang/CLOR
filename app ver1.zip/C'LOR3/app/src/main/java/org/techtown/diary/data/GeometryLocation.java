package org.techtown.diary.data;

public class GeometryLocation {

    public double lat;
    public double lng;

    @Override
    public String toString() {
        return "GeometryLocation{" +
                "lat=" + lat +
                ", lng=" + lng +
                '}';
    }
}
