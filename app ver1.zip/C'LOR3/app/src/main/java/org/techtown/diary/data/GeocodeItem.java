package org.techtown.diary.data;

public class GeocodeItem {

    public String formatted_address;
    public Geometry geometry;

}
